Welcome to the fathom wiki!

How to:

* [Install Fathom with our One-Click DigitalOcean installer](DigitalOcean%20One-Click%20Installation%20Instructions.md)
* [Installing and running Fathom](Installation%20instructions.md)
* [Upgrading Fathom to the latest version](Updating%20to%20the%20latest%20version.md)
* [Configuration](Configuration.md)
* [Frequently asked questions](FAQ.md)

Misc:

* [Using Fathom with Systemd](misc/Systemd.md)
* [Running Fathom with NGINX](misc/NGINX.md)
* [Running Fathom on Heroku](misc/Heroku.md)
