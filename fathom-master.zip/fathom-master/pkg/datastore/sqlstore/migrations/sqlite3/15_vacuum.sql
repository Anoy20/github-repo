-- +migrate Up  notransaction
VACUUM;

-- +migrate Down 